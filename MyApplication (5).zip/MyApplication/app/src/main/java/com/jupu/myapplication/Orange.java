package com.jupu.myapplication;

public class Orange extends Lutemon {

    public Orange(String name) {
        super(name, "ornage", 6, 3, 0, 19, 19, 222,1);
        image = R.drawable.orangelutemon;
    }
}
