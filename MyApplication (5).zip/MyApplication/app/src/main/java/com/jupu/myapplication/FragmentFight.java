package com.jupu.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@lin factory method to
 * create an instance of this fragment.
 */
public class FragmentFight extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_fight, container, false);
    }

    private ArrayList<Integer> list = new ArrayList<>();
    private Button FightBtn;
    private TextView textBox;
    private int round = 0;
    private int i = 0;
    private int j = 0;


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //greate check box
        CheckBox b1 = view.findViewById(R.id.checkBox2_1);
        CheckBox b2 = view.findViewById(R.id.checkBox2_2);
        CheckBox b3 = view.findViewById(R.id.checkBox2_3);
        CheckBox b4 = view.findViewById(R.id.checkBox2_4);
        CheckBox b5 = view.findViewById(R.id.checkBox2_5);
        //create radio buttons and clickable button
        FightBtn = view.findViewById(R.id.btnFight);
        textBox = view.findViewById(R.id.textFightBox);
        //set every check box to invisible
        b1.setVisibility(View.INVISIBLE);
        b2.setVisibility(View.INVISIBLE);
        b3.setVisibility(View.INVISIBLE);
        b4.setVisibility(View.INVISIBLE);
        b5.setVisibility(View.INVISIBLE);
        //Create index array which lutemons are at fight
        list.add(0, 0);
        list.add(1, 0);
        list.add(2, 0);
        list.add(3, 0);
        list.add(4, 0);
        // Check which of lutemons are fight and get index
        for (Lutemon lut : Storage.getInstance().getLutemons()) {
            if (lut.status == 3) {
                list.set(i, j);
                i++;
                j++;
            } else {
                j++;
            }
        }
        //Set checkbox to visible and set name for the box
        if (Storage.getInstance().numberOfLutemonsFight() > 0) {
            b1.setVisibility(View.VISIBLE);
            b1.setText(Storage.getInstance().getLutemons().get(list.get(0)).name);
        }
        if (Storage.getInstance().numberOfLutemonsFight() > 1) {
            b2.setVisibility(View.VISIBLE);
            b2.setText(Storage.getInstance().getLutemons().get(list.get(1)).name);
        }
        if (Storage.getInstance().numberOfLutemonsFight() > 2) {
            b3.setVisibility(View.VISIBLE);
            b3.setText(Storage.getInstance().getLutemons().get(list.get(2)).name);
        }
        if (Storage.getInstance().numberOfLutemonsFight() > 3) {
            b4.setVisibility(View.VISIBLE);
            b4.setText(Storage.getInstance().getLutemons().get(list.get(3)).name);
        }
        if (Storage.getInstance().numberOfLutemonsFight() > 4) {
            b5.setVisibility(View.VISIBLE);
            b5.setText(Storage.getInstance().getLutemons().get(list.get(4)).name);
        }
        //Create onclick listener and move lutemons for fight
        //prison rules you can go to back home only if you win
        FightBtn.setOnClickListener(new View.OnClickListener() {
            private Lutemon lutA;
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                if(b1.isChecked()){
                    Storage.getInstance().getLutemons().get(list.get(0)).status = 5;
                }
                if(b2.isChecked()){
                    Storage.getInstance().getLutemons().get(list.get(1)).status = 5;
                }
                if(b3.isChecked()){
                    Storage.getInstance().getLutemons().get(list.get(2)).status = 5;
                }
                if(b4.isChecked()){
                    Storage.getInstance().getLutemons().get(list.get(3)).status = 5;
                }
                if(b5.isChecked()){
                    Storage.getInstance().getLutemons().get(list.get(4)).status = 5;
                }
                textBox.setText("");
                while (Storage.getInstance().getLutemons().get(list.get(0)).health >= 0 && Storage.getInstance().getLutemons().get(list.get(1)).health >= 0) {
                    textBox.append("1: " + Storage.getInstance().getLutemons().get(list.get(0)).color + "(" + Storage.getInstance().getLutemons().get(list.get(0)).name + ") att: "
                            + Storage.getInstance().getLutemons().get(list.get(0)).attack + "; def: " + Storage.getInstance().getLutemons().get(list.get(0)).defence + "; exp: "
                            + Storage.getInstance().getLutemons().get(list.get(0)).experience + "; health: " + Storage.getInstance().getLutemons().get(list.get(0)).health + "/"
                            + Storage.getInstance().getLutemons().get(list.get(0)).max_health + "\n");
                    textBox.append("2: " + Storage.getInstance().getLutemons().get(list.get(1)).color + "(" + Storage.getInstance().getLutemons().get(list.get(1)).name + ") att: "
                            + Storage.getInstance().getLutemons().get(list.get(1)).attack + "; def: " + Storage.getInstance().getLutemons().get(list.get(1)).defence + "; exp: "
                            + Storage.getInstance().getLutemons().get(list.get(1)).experience + "; health: " + Storage.getInstance().getLutemons().get(list.get(1)).health + "/"
                            + Storage.getInstance().getLutemons().get(list.get(1)).max_health + "\n");
                    if (round == 0) {
                        Storage.getInstance().getLutemons().get(list.get(1)).health -= Storage.getInstance().getLutemons().get(list.get(0)).attack;
                        if (Storage.getInstance().getLutemons().get(list.get(1)).health > 0) {
                            textBox.append(Storage.getInstance().getLutemons().get(list.get(0)).color + "(" + Storage.getInstance().getLutemons().get(list.get(0)).name
                                    + ") attach and " + Storage.getInstance().getLutemons().get(list.get(1)).color + "(" + Storage.getInstance().getLutemons().get(list.get(1)).name
                                    + ") manages to escape death \n");
                            Storage.getInstance().getLutemons().get(list.get(0)).status = 3;
                            Storage.getInstance().getLutemons().get(list.get(1)).status = 3;
                        }
                        if (Storage.getInstance().getLutemons().get(list.get(1)).health <= 0) {
                            textBox.append(Storage.getInstance().getLutemons().get(list.get(0)).color + "(" + Storage.getInstance().getLutemons().get(list.get(0)).name
                                    + ") attach and " + Storage.getInstance().getLutemons().get(list.get(1)).color + "(" + Storage.getInstance().getLutemons().get(list.get(1)).name
                                    + ") die \n");
                            Storage.getInstance().getLutemons().get(list.get(0)).status = 1;
                            Storage.getInstance().getLutemons().get(list.get(1)).status = 4;
                        }
                        round++;
                    }
                    else {
                        Storage.getInstance().getLutemons().get(list.get(0)).health -= Storage.getInstance().getLutemons().get(list.get(1)).attack;
                        if (Storage.getInstance().getLutemons().get(list.get(0)).health > 0) {
                            textBox.append(Storage.getInstance().getLutemons().get(list.get(1)).color + "(" + Storage.getInstance().getLutemons().get(list.get(1)).name
                                    + ") attach and " + Storage.getInstance().getLutemons().get(list.get(0)).color + "(" + Storage.getInstance().getLutemons().get(list.get(0)).name
                                    + ") manages to escape death \n");
                            Storage.getInstance().getLutemons().get(list.get(0)).status = 3;
                            Storage.getInstance().getLutemons().get(list.get(1)).status = 3;
                        }
                        if (Storage.getInstance().getLutemons().get(list.get(0)).health <= 0) {
                            textBox.append(Storage.getInstance().getLutemons().get(list.get(1)).color + "(" + Storage.getInstance().getLutemons().get(list.get(1)).name
                                    + ") attach and " + Storage.getInstance().getLutemons().get(list.get(0)).color + "(" + Storage.getInstance().getLutemons().get(list.get(0)).name
                                    + ") die \n");
                            Storage.getInstance().getLutemons().get(list.get(0)).status = 4;
                            Storage.getInstance().getLutemons().get(list.get(1)).status = 1;
                        }
                        round--;
                    }
                }
            }
        });
    }
}