package com.jupu.myapplication;

import java.util.ArrayList;

public class Storage {
     private ArrayList<Lutemon> Lutemons = new ArrayList<>();
     private static Storage storage = null;
     private Storage() {
     }

    public static Storage getInstance() {
        if(storage == null) {
            storage = new Storage();
        }
        return storage;
    }

    public ArrayList<Lutemon> getLutemons() {
        return Lutemons;
    }

    public void addLutemon(Lutemon Lutemon) {
        Lutemons.add(Lutemon);
    }

    public int numberOfLutemonsHome() {
        int number = 0;
        for (Lutemon Lutemon : Lutemons) {
            if(Lutemon.status == 1) {
                number = number + 1;
            }
        }
        return number;
    }

    public int numberOfLutemonsTrain() {
        int number = 0;
        for (Lutemon Lutemon : Lutemons) {
            if(Lutemon.status == 2) {
                number = number + 1;
            }
        }
        return number;
    }

    public int numberOfLutemonsFight() {
        int number = 0;
        for (Lutemon Lutemon : Lutemons) {
            if(Lutemon.status == 3) {
                number = number + 1;
            }
        }
        return number;
    }

    public int numberOfLutemonsDead() {
        int number = 0;
        for (Lutemon Lutemon : Lutemons) {
            if(Lutemon.status == 4) {
                number = number + 1;
            }
        }
        return number;
    }
}
