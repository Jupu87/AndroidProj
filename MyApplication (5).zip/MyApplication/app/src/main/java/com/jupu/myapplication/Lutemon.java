package com.jupu.myapplication;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class Lutemon {
    protected String name;
    protected String color;
    protected int attack;
    protected int defence;
    protected int experience;
    protected int health;
    protected int max_health;
    protected int id;
    protected int status; //1 = home, 2 = training, 3 = fight, 4 = dead, 5 = fighting just now
    public int id_counter;
    protected int image;
    //protected ArrayList<RocketEngine> engines = new ArrayList<>();
    //protected int id;
    protected static final long serialVersionUID = 242;

    public static int lutemonCounter = 0;

    public Lutemon() {
        this("lutemon", "gray", 1, 1, 1, 1, 10, 222, 1);
    }

    public Lutemon(String name, String color, int attack, int defence, int experimence, int health, int max_health, int id, int status) {
        this.name = name;
        this.color = color;
        this.attack = attack;
        this.defence = defence;
        this.experience = experimence;
        this.health = health;
        this.max_health = max_health;
        this.id = id;
        this.status = status;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setColor(String Color) {
        this.color = color;
    }
    public void setAttack(int attack) {
        this.attack = attack;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setName(int name) {
        this.name = String.valueOf(name);
    }
    public void setColor(int color) {
        this.color = String.valueOf(color);
    }
    public int getAttack() {
        return attack;
    }
    public void addLutemon(Lutemon lutemon){
        lutemon.addLutemon(lutemon);
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public int getImage() {
        return image;
    }
    public int setStatus() {return status; }
    public String toString() {
        return name;
    }
}
