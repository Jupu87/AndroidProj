package com.jupu.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@lin factory method to
 * create an instance of this fragment.
 */
public class FragmentDead extends Fragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_dead, container, false);
    }


    private ArrayList<Integer> list = new ArrayList<>();

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //greate check box
        CheckBox b1 = view.findViewById(R.id.checkBox3_1);
        CheckBox b2 = view.findViewById(R.id.checkBox3_2);
        CheckBox b3 = view.findViewById(R.id.checkBox3_3);
        CheckBox b4 = view.findViewById(R.id.checkBox3_4);
        CheckBox b5 = view.findViewById(R.id.checkBox3_5);
        //set every check box to invisible
        b1.setVisibility(View.INVISIBLE);
        b2.setVisibility(View.INVISIBLE);
        b3.setVisibility(View.INVISIBLE);
        b4.setVisibility(View.INVISIBLE);
        b5.setVisibility(View.INVISIBLE);
        //Create index array which lutemons are dead
        list.add(0, 0);
        list.add(1, 0);
        list.add(2, 0);
        list.add(3, 0);
        list.add(4, 0);
        // Check which of lutemons are dead and get index
        int i = 0;
        int j = 0;
        for (Lutemon lut : Storage.getInstance().getLutemons()) {
            if (lut.status == 4) {
                list.set(i, j);
                i++;
                j++;
            } else {
                j++;
            }
        }

        //Set checkbox to visible and set name for the box
        if (Storage.getInstance().numberOfLutemonsDead() > 0) {
            b1.setVisibility(View.VISIBLE);
            b1.setText(Storage.getInstance().getLutemons().get(list.get(0)).name);
        }
        if (Storage.getInstance().numberOfLutemonsDead() > 1) {
            b2.setVisibility(View.VISIBLE);
            b2.setText(Storage.getInstance().getLutemons().get(list.get(1)).name);
        }
        if (Storage.getInstance().numberOfLutemonsDead() > 2) {
            b3.setVisibility(View.VISIBLE);
            b3.setText(Storage.getInstance().getLutemons().get(list.get(2)).name);
        }
        if (Storage.getInstance().numberOfLutemonsDead() > 3) {
            b4.setVisibility(View.VISIBLE);
            b4.setText(Storage.getInstance().getLutemons().get(list.get(3)).name);
        }
        if (Storage.getInstance().numberOfLutemonsDead() > 4) {
            b5.setVisibility(View.VISIBLE);
            b5.setText(Storage.getInstance().getLutemons().get(list.get(4)).name);
        }
    }

}