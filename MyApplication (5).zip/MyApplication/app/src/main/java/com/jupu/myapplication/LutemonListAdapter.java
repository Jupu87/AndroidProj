package com.jupu.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class LutemonListAdapter extends RecyclerView.Adapter<LutemonViewHolder> {

    private Context context;
    private ArrayList<Lutemon> Lutemons = new ArrayList<>();
    public LutemonListAdapter(Context context, ArrayList<Lutemon> Lutemons) {
        this.context = context;
        this.Lutemons = Lutemons;
    }
    @NonNull
    @Override
    public LutemonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new LutemonViewHolder(LayoutInflater.from(context).inflate(R.layout.lutemon_view, parent, false));
    }
    @Override
    public void onBindViewHolder(@NonNull LutemonViewHolder holder, int position) {
        holder.lutemonName.setText(Lutemons.get(position).getName() + " (" + Lutemons.get(position).getId() +")");
        holder.lutemonImage.setImageResource(Lutemons.get(position).getImage());
    }
    @Override
    public int getItemCount() {
        return Lutemons.size();
    }
}
