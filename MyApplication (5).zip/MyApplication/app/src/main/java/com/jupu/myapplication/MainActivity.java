package com.jupu.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnnaddNewLutemon;
    private Button btnlistLutemons;
    private Button btnmoveLutemons;

    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = MainActivity.this;

        btnnaddNewLutemon = (Button) findViewById(R.id.addNewLutemon);
        btnnaddNewLutemon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                switchToAddLu(view);
            }
        });
        btnlistLutemons = (Button) findViewById(R.id.listLutemons);
        btnlistLutemons.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) { listLut(view);}
        });
        btnmoveLutemons = (Button) findViewById(R.id.moveLutemons);
        btnmoveLutemons.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) { moveLut(view);}
        });
    }
    public void switchToAddLu(View view) {
        Intent intent = new Intent(this, AddLutActivity.class);
        startActivity(intent);
    }
    public void listLut(View view) {
        Intent intent =new Intent(this, ListLut.class);
        startActivity(intent);
    }
    public void moveLut(View view) {
        Intent intent =new Intent(this, MoveLutemons.class);
        startActivity(intent);
    }
}