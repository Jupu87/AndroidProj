package com.jupu.myapplication;

public class White extends Lutemon {

    public White(String name) {
        super(name, "white", 5, 4, 0, 20, 20, 222,1);
        image = R.drawable.whitelutemon;
    }
}
