package com.jupu.myapplication;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;
import com.jupu.myapplication.MoveLutemons;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@lin factory method to
 * create an instance of this fragment.
 */
public class FragmentHome extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    private ArrayList<Integer> list = new ArrayList<>();
    private Button addBtn;
    private RadioButton toTrain;
    private RadioButton toFight;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //greate check box
        CheckBox b1 = view.findViewById(R.id.checkBox1);
        CheckBox b2 = view.findViewById(R.id.checkBox3);
        CheckBox b3 = view.findViewById(R.id.checkBox4);
        CheckBox b4 = view.findViewById(R.id.checkBox5);
        CheckBox b5 = view.findViewById(R.id.checkBox6);
        //create radio buttons and clickable button
        addBtn = view.findViewById(R.id.btnMoveSelected);
        toTrain = view.findViewById(R.id.RdBtnTrain);
        toFight = view.findViewById(R.id.RdBtnFight);
        //set every check box to invisible
        b1.setVisibility(View.INVISIBLE);
        b2.setVisibility(View.INVISIBLE);
        b3.setVisibility(View.INVISIBLE);
        b4.setVisibility(View.INVISIBLE);
        b5.setVisibility(View.INVISIBLE);
        //Create index array which lutemons are at home
        list.add(0, 0);
        list.add(1, 0);
        list.add(2, 0);
        list.add(3, 0);
        list.add(4, 0);
        // Check which of lutemons are training and get index
        int i = 0;
        int j = 0;
        for (Lutemon lut : Storage.getInstance().getLutemons()) {
            if (lut.status == 1) {
                list.set(i, j);
                i++;
                j++;
            } else {
                j++;
            }
        }

        //Set checkbox to visible and set name for the box
        if (Storage.getInstance().numberOfLutemonsHome() > 0) {
            b1.setVisibility(View.VISIBLE);
            b1.setText(Storage.getInstance().getLutemons().get(list.get(0)).name);
        }
        if (Storage.getInstance().numberOfLutemonsHome() > 1) {
            b2.setVisibility(View.VISIBLE);
            b2.setText(Storage.getInstance().getLutemons().get(list.get(1)).name);
        }
        if (Storage.getInstance().numberOfLutemonsHome() > 2) {
            b3.setVisibility(View.VISIBLE);
            b3.setText(Storage.getInstance().getLutemons().get(list.get(2)).name);
        }
        if (Storage.getInstance().numberOfLutemonsHome() > 3) {
            b4.setVisibility(View.VISIBLE);
            b4.setText(Storage.getInstance().getLutemons().get(list.get(3)).name);
        }
        if (Storage.getInstance().numberOfLutemonsHome() > 4) {
            b5.setVisibility(View.VISIBLE);
            b5.setText(Storage.getInstance().getLutemons().get(list.get(4)).name);
        }
        //create on click listener and move selected lutemons for the next place
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("testinappi");
                if(toTrain.isChecked()){
                    if(b1.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(0)).status = 2;
                    }
                    if(b2.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(1)).status = 2;
                    }
                    if(b3.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(2)).status = 2;
                    }
                    if(b4.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(3)).status = 2;
                    }
                    if(b5.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(4)).status = 2;
                    }

                }
                if(toFight.isChecked()){
                    if(b1.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(0)).status = 3;
                    }
                    if(b2.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(1)).status = 3;
                    }
                    if(b3.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(2)).status = 3;
                    }
                    if(b4.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(3)).status = 3;
                    }
                    if(b5.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(4)).status = 3;
                    }
                }
                // update fragment
                getActivity().getSupportFragmentManager().beginTransaction().replace(FragmentHome.this.getId(), new FragmentHome()).commit();
                }
            });
    }
}