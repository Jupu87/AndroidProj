package com.jupu.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AddLutActivity extends AppCompatActivity {

    private EditText textInput;
    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_lutemon);
    }
    @SuppressLint("WrongViewCast")
    public void addLut(View view) {
        RadioGroup rgLutType = findViewById(R.id.rgLutType);
        textInput = findViewById(R.id.editTextInput);
        name = String.valueOf(textInput.getText());

        //Add new lutemon for the storage
        int id = rgLutType.getCheckedRadioButtonId();
        if (id == R.id.rbWhite) {
            Storage.getInstance().addLutemon(new White(name));
        } else if (id == R.id.rbGreen) {
            Storage.getInstance().addLutemon(new Green(name));;
        } else if (id == R.id.rbPink) {
            Storage.getInstance().addLutemon(new Pink(name));;
        } else if (id == R.id.rbOrange) {
            Storage.getInstance().addLutemon(new Orange(name));;
        } else if (id == R.id.rbBlack) {
            Storage.getInstance().addLutemon(new Black(name));;
        }


    }

}


