package com.jupu.myapplication;

public class Pink extends Lutemon {

    public Pink(String name) {
        super(name, "pink", 7, 2, 0, 18, 18, 222,1);
        image = R.drawable.pinklutemon;
    }
}
