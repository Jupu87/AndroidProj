package com.jupu.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@lin factory method to
 * create an instance of this fragment.
 */
public class FragmentTrain extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_training, container, false);
    }

    private ArrayList<Integer> list = new ArrayList<>();
    private Button moveBtn;
    private RadioButton toHome;
    private RadioButton toFight;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //create check box
        CheckBox b1 = view.findViewById(R.id.checkBox1_1);
        CheckBox b2 = view.findViewById(R.id.checkBox1_2);
        CheckBox b3 = view.findViewById(R.id.checkBox1_3);
        CheckBox b4 = view.findViewById(R.id.checkBox1_4);
        CheckBox b5 = view.findViewById(R.id.checkBox1_5);
        //create radio buttons and clickable button
        moveBtn = view.findViewById(R.id.btnMoveSelected_1);
        toHome = view.findViewById(R.id.RdBtnTHome_1);
        toFight = view.findViewById(R.id.RdBtnTFight_1);
        //set every check box to invisible
        b1.setVisibility(View.INVISIBLE);
        b2.setVisibility(View.INVISIBLE);
        b3.setVisibility(View.INVISIBLE);
        b4.setVisibility(View.INVISIBLE);
        b5.setVisibility(View.INVISIBLE);
        //Create index array which lutemons are training
        list.add(0, 0);
        list.add(1, 0);
        list.add(2, 0);
        list.add(3, 0);
        list.add(4, 0);
        // Check which of lutemons are training and get index
        int i = 0;
        int j = 0;
        for (Lutemon lut : Storage.getInstance().getLutemons()) {
            if (lut.status == 2) {
                list.set(i, j);
                i++;
                j++;
            } else {
                j++;
            }
        }

        //Set checkbox to visible and set name for the box
        if (Storage.getInstance().numberOfLutemonsTrain() > 0) {
            b1.setVisibility(View.VISIBLE);
            b1.setText(Storage.getInstance().getLutemons().get(list.get(0)).name);
            // Add training points for the lutemon
            Storage.getInstance().getLutemons().get(list.get(0)).attack += 2;
            Storage.getInstance().getLutemons().get(list.get(0)).defence += 2;
            if(Storage.getInstance().getLutemons().get(list.get(0)).health <
                    Storage.getInstance().getLutemons().get(list.get(0)).max_health){
                Storage.getInstance().getLutemons().get(list.get(0)).health += 2;
            }
        }
        if (Storage.getInstance().numberOfLutemonsTrain() > 1) {
            b2.setVisibility(View.VISIBLE);
            b2.setText(Storage.getInstance().getLutemons().get(list.get(1)).name);
            // Add training points for the lutemon
            Storage.getInstance().getLutemons().get(list.get(1)).attack += 2;
            Storage.getInstance().getLutemons().get(list.get(1)).defence += 2;
            if(Storage.getInstance().getLutemons().get(list.get(1)).health <
                    Storage.getInstance().getLutemons().get(list.get(1)).max_health){
                Storage.getInstance().getLutemons().get(list.get(1)).health += 2;
            }
        }
        if (Storage.getInstance().numberOfLutemonsTrain() > 2) {
            b3.setVisibility(View.VISIBLE);
            b3.setText(Storage.getInstance().getLutemons().get(list.get(2)).name);
            // Add training points for the lutemon
            Storage.getInstance().getLutemons().get(list.get(2)).attack += 2;
            Storage.getInstance().getLutemons().get(list.get(2)).defence += 2;
            if(Storage.getInstance().getLutemons().get(list.get(2)).health <
                    Storage.getInstance().getLutemons().get(list.get(2)).max_health){
                Storage.getInstance().getLutemons().get(list.get(2)).health += 2;
            }
        }
        if (Storage.getInstance().numberOfLutemonsTrain() > 3) {
            b4.setVisibility(View.VISIBLE);
            b4.setText(Storage.getInstance().getLutemons().get(list.get(3)).name);
            // Add training points for the lutemon
            Storage.getInstance().getLutemons().get(list.get(3)).attack += 2;
            Storage.getInstance().getLutemons().get(list.get(3)).defence += 2;
            if(Storage.getInstance().getLutemons().get(list.get(3)).health <
                    Storage.getInstance().getLutemons().get(list.get(3)).max_health){
                Storage.getInstance().getLutemons().get(list.get(3)).health += 2;
            }
        }
        if (Storage.getInstance().numberOfLutemonsTrain() > 4) {
            b5.setVisibility(View.VISIBLE);
            b5.setText(Storage.getInstance().getLutemons().get(list.get(4)).name);
            // Add training points for the lutemon
            Storage.getInstance().getLutemons().get(list.get(4)).attack += 2;
            Storage.getInstance().getLutemons().get(list.get(4)).defence += 2;
            if(Storage.getInstance().getLutemons().get(list.get(4)).health <
                    Storage.getInstance().getLutemons().get(list.get(4)).max_health){
                Storage.getInstance().getLutemons().get(list.get(4)).health += 2;
            }
        }
        //Create onclick listener and move selected lutemons for the next place
        moveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(toHome.isChecked()){
                    if(b1.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(0)).status = 1;
                    }
                    if(b2.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(1)).status = 1;
                    }
                    if(b3.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(2)).status = 1;
                    }
                    if(b4.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(3)).status = 1;
                    }
                    if(b5.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(4)).status = 1;
                    }

                }
                if(toFight.isChecked()){
                    if(b1.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(0)).status = 3;
                    }
                    if(b2.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(1)).status = 3;
                    }
                    if(b3.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(2)).status = 3;
                    }
                    if(b4.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(3)).status = 3;
                    }
                    if(b5.isChecked()){
                        Storage.getInstance().getLutemons().get(list.get(4)).status = 3;
                    }

                }
                //update fragment
                getActivity().getSupportFragmentManager().beginTransaction().replace(FragmentTrain.this.getId(), new FragmentTrain()).commit();

            }
        });
    }
}