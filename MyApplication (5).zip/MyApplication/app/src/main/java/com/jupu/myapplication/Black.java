package com.jupu.myapplication;

public class Black extends Lutemon {

    public Black(String name) {
        super(name, "black", 6, 3, 0, 19, 19, 222,1);
        image = R.drawable.blacklutemon;
    }
}
