package com.jupu.myapplication;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
public class MoveLutemons extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move_lutemons);

        Button fragmentHome = findViewById(R.id.tabItem1);
        Button fragmentTrain = findViewById(R.id.tabItem2);
        Button fragmentFight = findViewById(R.id.tabItem3);
        Button fragmentDead = findViewById(R.id.tabItem4);

        fragmentHome.setOnClickListener(listener);
        fragmentTrain.setOnClickListener(listener);
        fragmentFight.setOnClickListener(listener);
        fragmentDead.setOnClickListener(listener);

        Fragment fragment;
        fragment = new FragmentHome();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentArea2, fragment)
                .commit();
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Fragment fragment;

            int id = view.getId();
            if (id == R.id.tabItem1) {
                fragment = new FragmentHome();
            } else if (id == R.id.tabItem2) {
                fragment = new FragmentTrain();
            } else if (id == R.id.tabItem3) {
                fragment = new FragmentFight();
            } else if (id == R.id.tabItem4) {
                fragment = new FragmentDead();
            } else {fragment = new FragmentHome();}

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentArea2, fragment)
                    .commit();
        }
    };
}
