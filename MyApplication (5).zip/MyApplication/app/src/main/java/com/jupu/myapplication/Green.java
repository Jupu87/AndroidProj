package com.jupu.myapplication;

public class Green extends Lutemon {
    public Green(String name) {
        super(name, "green", 6, 3, 0, 19, 19, 222,1);
        image = R.drawable.greenlutemon;
    }
}
